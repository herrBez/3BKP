# 3BKP
The three-dimensional knapsack problem with balancing constraint

#Compilation
make
#Usage
./main <instance.dat>
#Instance 
are contained in the instance directory
